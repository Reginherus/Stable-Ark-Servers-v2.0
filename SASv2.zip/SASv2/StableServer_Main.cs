﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using IniParser;
using IniParser.Model;

namespace SASv2
{
    class StableServer_Main
    {
        static int numOfServers;
        static List<ArkServerInfo> Servers = new List<ArkServerInfo>();
        private static int nRunningEventsTriggered = 1;

        static void Main(string[] args)
        {
            Console.WriteLine("Load server info from file?");
            if (Console.ReadLine() == "y")
            {
                foreach (var server in ServersArrayPreSplit())
                {
                    ArkServerInfo tempServer = new ArkServerInfo();
                    string[] serverInfo = { "" };
                    serverInfo = server.Split(',');
                    tempServer.Name = serverInfo[0];
                    tempServer.ServerDir = serverInfo[1];
                    Servers.Add(tempServer);
                }
                foreach (var server in Servers)
                {
                    Console.WriteLine("Build Version: " + VersionUpdate.GetGameInformation(376030));
                    Console.WriteLine("Game Version: " + VersionUpdate.GetGameBuildID(server));
                }
                Task forceVersionModUpdate = Task.Factory.StartNew(() => ForceVersionModUpdate(VersionServerInfo()));
                forceVersionModUpdate.Wait();
                Console.WriteLine(DateTime.Now + ": Forced version update complete.");

            }
            else
            {
                Console.WriteLine("How many servers do you want to add?");
                Int32.TryParse(Console.ReadLine(), out numOfServers);

                File.Delete(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServerDirectories.txt"));
                Console.WriteLine("Does all servers have the same ip address?");

                if (Console.ReadLine() == "y")
                {
                    Console.WriteLine("IP Address: ");
                    var ipAddress = Console.ReadLine();

                    //Add server to list
                    for (var i = 0; i < numOfServers; i++)
                    {
                        ArkServerInfo tempServer = new ArkServerInfo();
                        Console.WriteLine("Server Name: ");
                        tempServer.Name = Console.ReadLine();
                        //tempServer.IPAddress = ipAddress;
                        string shooterGameDir;
                        Console.WriteLine("Paste directory to shootergame.exe");
                        shooterGameDir = Console.ReadLine();

                        while (!Directory.Exists(shooterGameDir))
                        {
                            Console.WriteLine("Directory does not exist, try again: ");
                            shooterGameDir = Console.ReadLine();
                        }

                        tempServer.ServerDir = shooterGameDir + "\\";
                        File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServerDirectories.txt"), tempServer.Name + "," + tempServer.ServerDir + Environment.NewLine);

                        Servers.Add(tempServer);
                    }
                    
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }
                string versionServerDir;
                Console.WriteLine("Where is the update server located?");
                versionServerDir = Console.ReadLine();
                if (!Directory.Exists(versionServerDir))
                {
                    while (!Directory.Exists(versionServerDir))
                    {
                        Console.WriteLine("Directory not found. Try again: ");
                        versionServerDir = Console.ReadLine();
                    }
                }
                else
                {
                    ArkServerInfo tempServer = new ArkServerInfo();
                    tempServer.Name = "UpdateServer";
                    tempServer.ServerDir = versionServerDir + @"\";
                    File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServerDirectories.txt"), tempServer.Name + "," + tempServer.ServerDir + Environment.NewLine);



                }
                foreach (var server in Servers)
                {
                    string JSON = JsonConvert.SerializeObject(server, Formatting.Indented);
                    Console.WriteLine(JSON);
                    string path = server.iniDir + server.Name + ".txt";
                    if (!File.Exists(path))
                    {
                        string createText = "";
                        File.WriteAllText(path, createText);
                    }

                    File.AppendAllText(path, JSON);
                }
            }

            System.Timers.Timer primaryTimer = new System.Timers.Timer();
            primaryTimer.Interval = 60000;
            primaryTimer.Elapsed += (sender, e) => CheckRoutine(sender, e);
            primaryTimer.Start();

            Console.ReadKey();
        }
        private static void CheckRoutine(object sender, EventArgs e)
        {
            //Run Game Version Update every 20 minutes
            if (nRunningEventsTriggered % 20 == 0)
            {
                Methods.VersionUpdate(VersionServerInfo());
                Console.WriteLine(DateTime.Now + ": Updating Version Server.");
            }
            //Run Server check
            foreach (var Server in Servers)
            {
                if (Server != VersionServerInfo())
                {
                    Console.WriteLine(DateTime.Now + ": Entered " + Server.Name + "'s check method. RunningTimer = " + nRunningEventsTriggered);
                    bool processOpen = Methods.IsProcessOpen(Server);
                    bool ServerIsResponding = RCONCommands.IsServerResponding(Server);
                    Console.WriteLine("Server Response: " + ServerIsResponding);

                    if (!Server.stopServerTimer)
                    {
                        Server.ModUpdateNeeded = Methods.NeedsModUpdate(Server);
                        Console.WriteLine("Mods are up to date: " + !Server.ModUpdateNeeded);
                        Server.GameUpdateNeeded = Methods.NeedsArkUpdate(Server);
                        Console.WriteLine("Game is up to date: " + !Server.GameUpdateNeeded);

                        if (Server.ModUpdateNeeded && processOpen)
                        {
                            //Restart and Update the server if update is needed.
                            ServerRestartForModORRoutineMaintenance(Server, "Mod Update: " + Server.theModNeedingUpdate);
                            Server.ModUpdateNeeded = false;
                            Server.stopServerTimer = true;
                        }
                        //If process is open and game needs to be updated, trigger restart counter
                        if (Server.GameUpdateNeeded && processOpen)
                        {
                            ServerRestartForArkUpdateProcedure(Server, "Ark Update");
                            Server.GameUpdateNeeded = false;
                            Server.stopServerTimer = true;
                        }
                        if (processOpen && !ServerIsResponding)
                        {
                            if (Server.nEventsProcessOpenNotResponding == 10)
                            {
                                try
                                {
                                    Process[] processes = Process.GetProcessesByName(GlobalVariables.appName);
                                    foreach (Process clsProcess in processes)
                                    {
                                        if (clsProcess.ProcessName.Contains(GlobalVariables.appName))
                                        {
                                            if (clsProcess.MainModule.FileName.Contains(Server.ServerDir))
                                            {
                                                clsProcess.Kill();
                                                Methods.StartServerProcedure(Server);
                                                Server.stopServerTimer = true;

                                            }

                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(DateTime.Now + ": Exception occured when killing ShooterGameServer.exe. Exception: " + ex.Message);
                                    //Methods.Log(Ragnarok, DateTime.Now + ": Exception occured when killing ShooterGameServer.exe. Exception: " + ex.Message);

                                }
                            }

                            Server.nEventsProcessOpenNotResponding++;
                        }
                        if (!processOpen)
                        {
                            Methods.StartServerProcedure(Server);
                        }
                    }
                    ////If the server has ran for 12 hours, trigger the routine maintenance restart.
                    //if (nRagEventsTriggered % GlobalVariables.timeIntervalMaintenanceRestart == 0 && RagProcessOpen)
                    //{
                    //    ServerRestartForModORRoutineMaintenance(Ragnarok, "Routine Maintenance");
                    //    RagnarokTimerTriggerStopped = true;
                    //}
                    //Backup the server every 2 hours.
                    if (nRunningEventsTriggered % 60 == 0)
                    {
                        //Methods.BackupServerFiles(Ragnarok);

                    }
                }
            }
            nRunningEventsTriggered++;
        }
        public static void ServerRestartForModORRoutineMaintenance(ArkServerInfo Server, string Reason)
        {
            //Notifies players that a server restart is coming and gives the reason.
            RCONCommands.ServerRestartTriggered(Server, Reason);
            //Starts the restart timer. Every minute the players will be notified that a server restart is incoming. After (PresetTimeToRestart) minutes, the server will shut down.
            BroadCastModUpdateRestartTimer(Server);
        }

        private static void ServerRestartForArkUpdateProcedure(ArkServerInfo Server, string Reason)
        {
            //Notifies players that a server restart is coming and gives the reason.
            RCONCommands.ServerRestartTriggered(Server, Reason);
            //Starts the restart timer. Every minute the players will be notified that a server restart is incoming. After (PresetTimeToRestart) minutes, the server will shut down.
            BroadCastArkUpdateRestartTimer(Server);
        }
        public static void BroadCastArkUpdateRestartTimer(ArkServerInfo Server)
        {
            System.Timers.Timer restartTimer = new System.Timers.Timer();
            restartTimer.Interval = 60000;
            restartTimer.Elapsed += (sender, e) => BroadCastArkUpdateRestartNotification(sender, e, Server);

            restartTimer.Start();
        }
        private static void BroadCastArkUpdateRestartNotification(object sender, EventArgs e, ArkServerInfo Server)
        {
            int ticks = 0;

            ticks = Server.nOfTicks;
            //switch (port)
            //{
            //    case GlobalVariables.RagPort:
            //        ticks = nOfRagTicks;
            //        break;
            //    case GlobalVariables.CenterPort:
            //        ticks = nOfCenterTicks;
            //        break;
            //    case GlobalVariables.AbPort:
            //        ticks = nOfAbTicks;
            //        break;
            //}
            int minutesTillRestart = GlobalVariables.presetTimeToRestart - ticks;
            System.Timers.Timer timer = (System.Timers.Timer)sender;

            if (minutesTillRestart == 10)
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
            if (minutesTillRestart < 6 && minutesTillRestart > 0)
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
            //if (minutesTillRestart == 1)
            //    Methods.BackupServerFiles(Server);
            if (minutesTillRestart == 0)
            {
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
                timer.Close();
                ticks = Server.nOfTicks;
                //switch (port)
                //{
                //    case GlobalVariables.RagPort:
                //        nOfRagTicks = 0;
                //        break;
                //    case GlobalVariables.CenterPort:
                //        nOfCenterTicks = 0;
                //        break;
                //    case GlobalVariables.AbPort:
                //        nOfAbTicks = 0;
                //        break;
                //}
                Methods.ArkUpdateShutdownProcedure(Server);
            }
            if (minutesTillRestart != 0)
            {
                Server.nOfTicks++;
            }
                //switch (port)
                //{
                //    case GlobalVariables.CenterPort:
                //        nOfCenterTicks++;
                //        break;
                //    case GlobalVariables.RagPort:
                //        nOfRagTicks++;
                //        break;
                //    case GlobalVariables.AbPort:
                //        nOfAbTicks++;
                //        break;
                //}
        }

        public static void BroadCastModUpdateRestartTimer(ArkServerInfo Server)
        {

            System.Timers.Timer restartTimer = new System.Timers.Timer();
            restartTimer.Interval = 60000;
            restartTimer.Elapsed += (sender, e) => BroadCastModUpdateRestartNotification(sender, e, Server);

            restartTimer.Start();
        }
        private static void BroadCastModUpdateRestartNotification(object sender, EventArgs e, ArkServerInfo Server)
        {
            int ticks = 0;
            System.Timers.Timer timer = (System.Timers.Timer)sender;
            ticks = Server.nOfTicks;
            
            int minutesTillRestart = GlobalVariables.presetTimeToRestart - ticks;
            if (minutesTillRestart == 10)
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
            if (minutesTillRestart < 6 && minutesTillRestart > 0)
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
            //if (minutesTillRestart == 1)
            //    Methods.BackupServerFiles(Server);
            if (minutesTillRestart == 0)
            {
                RCONCommands.GlobalNotification(Server, GlobalVariables.serverRestartNotification(minutesTillRestart));
                timer.Close();

                Server.nOfTicks = 0;
                
                Methods.ModUpdateShutdownProcedure(Server);
            }
            if (minutesTillRestart != 0)
            {
                Server.nOfTicks++;
            }
                

        }
        private static string[] ServersArrayPreSplit()
        {
            return File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServerDirectories.txt"));
        }
        public static ArkServerInfo VersionServerInfo()
        {
            foreach (var server in Servers)
            {
                if(server.Name == "UpdateServer")
                {
                    return server;
                }
            }
            return null;
        }
        private static void ForceVersionModUpdate(ArkServerInfo vServer)
        {
            //Make sure that all active mods are inside Version Server GUS.ini
            string[] allMods = Methods.AllActiveServerMods();
            string ActiveModsLine = "";
            string last = allMods.Last();
            foreach (string mod in allMods)
            {
                if (last != mod)
                {
                    ActiveModsLine = ActiveModsLine + mod + ",";
                }
                else
                {
                    ActiveModsLine = ActiveModsLine + mod;
                }

            }

            //Write all mods to Version Server GUS.ini
            FileIniDataParser fileIniData = new FileIniDataParser();
            IniData parsedData = fileIniData.ReadFile(vServer.GUSFile);
            parsedData["ServerSettings"]["ActiveMods"] = ActiveModsLine;
            fileIniData.WriteFile(vServer.GUSFile, parsedData);

            //Launch Version Server and Wait to finish
            Task VersionUpdateTask = Task.Factory.StartNew(() => Methods.VersionUpdate(vServer));
            VersionUpdateTask.Wait();

        }
    }
}
