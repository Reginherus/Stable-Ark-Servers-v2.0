﻿using IniParser;
using IniParser.Model;
using SteamACFReader;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SASv2
{
    class Methods
    {
        
        public static void StartServerProcedure(ArkServerInfo Server)
        {
            Task startServer = Task.Factory.StartNew(() => ServerStartCommand(Server));
            startServer.Wait(2000);
        }
        public static void ServerStartCommand(ArkServerInfo Server)
        {
            Process startServer = new Process();
            startServer.StartInfo.FileName = Server.RunBatFile;
            startServer.StartInfo.CreateNoWindow = false;

            startServer.Start();

            //Start a boot timer to make sure server boots properly. If not, close app and restart every 15 minutes until successful.
            System.Timers.Timer bootTimer = new System.Timers.Timer();
            bootTimer.Interval = 20000;
            bootTimer.Elapsed += (sender, e) => HasServerBooted(sender, e, Server);

            bootTimer.Start();

        }
        private static void HasServerBooted(object sender, EventArgs e, ArkServerInfo Server)
        {
            if (IsProcessOpen(Server))
            {
                if (RCONCommands.IsServerResponding(Server))
                {
                    Server.nNotRunning = 0;
                        
                    //StableServer.nAbEventsTriggered = 1;
                    Server.nEventsProcessOpenNotResponding = 0;
                    Server.stopServerTimer = false;
                        
                ((System.Timers.Timer)sender).Close();

                }
                if (Server.nNotRunning == 45)
                {
                    Console.WriteLine(DateTime.Now + ": Killing Server " + Server.Name + " due to boot time exceeding " + Server.nNotRunning * ((System.Timers.Timer)sender).Interval / 60000 + " minutes.");
                    //Log(port, DateTime.Now + ": Killing Server " + port + " due to boot time exceeding " + nEventsNotRunning * ((System.Timers.Timer)sender).Interval / 60000 + " minutes.");
                    //kill process and restart it.
                    try
                    {
                        Process[] processes = Process.GetProcessesByName(GlobalVariables.appName);
                        foreach (Process clsProcess in processes)
                        {
                            if (clsProcess.ProcessName.Contains(GlobalVariables.appName))
                            {
                                if (clsProcess.MainModule.FileName.Contains(Server.ServerDir))
                                {
                                    clsProcess.Kill();
                                    ((System.Timers.Timer)sender).Close();
                                    Thread.Sleep(2000);
                                    StartServerProcedure(Server);
                                }

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(DateTime.Now + ": Exception occured when killing ShooterGameServer.exe. Exception: " + ex.Message);
                        //Log(port, DateTime.Now + ": Exception occured when killing ShooterGameServer.exe. Exception: " + ex.Message);
                    }
                    //Reset Events not running
                    Server.nNotRunning = 0;
                }
                Server.nNotRunning++;
            }
        }
        public static void ArkUpdateShutdownProcedure(ArkServerInfo Server)
        {
            if (RCONCommands.WorldSave(Server))
            {
                RCONCommands.ShutdownServer(Server);
            }
            Thread.Sleep(2000);
            ServerUpdate(Server);
        }
        public static void ModUpdateShutdownProcedure(ArkServerInfo Server)
        {
            if (RCONCommands.WorldSave(Server))
            {
                RCONCommands.ShutdownServer(Server);
            }
            Thread.Sleep(2000);
            ServerUpdate(Server);
        }
        public static void VersionUpdate(ArkServerInfo Server)
        {
            string command = "+login anonymous +force_install_dir " + Server.ServerDir + " +app_update 376030";
            command = command + " +force_install_dir " + Server.SteamCMDDir;
            foreach (string mod in AllActiveServerMods())
            {
                command = command + " +workshop_download_item 346110 " + mod;
            }

            command = command + " +quit";

            Process steamUpdateServer = new Process();
            steamUpdateServer.StartInfo.UseShellExecute = true;
            steamUpdateServer.StartInfo.RedirectStandardInput = false;
            steamUpdateServer.StartInfo.RedirectStandardOutput = false;
            steamUpdateServer.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            steamUpdateServer.EnableRaisingEvents = true;
            steamUpdateServer.StartInfo.FileName = Server.SteamCMDDir + "\\SteamCMD.exe ";
            steamUpdateServer.StartInfo.Arguments = command;

            steamUpdateServer.Start();
            steamUpdateServer.WaitForExit();
            steamUpdateServer.Exited += (sender, e) =>
            {
                Console.WriteLine(DateTime.Now + ": Process Complete for " + Server.GamePort + "    Time: {0} sec " +
                "Exit code:    {1}", DateTime.Now.Second - steamUpdateServer.StartTime.Second, steamUpdateServer.ExitCode);

                ((Process)sender).Dispose();
            };
        }
        public static void ServerUpdate(ArkServerInfo Server)
        {
            
            Process steamUpdateServer = new Process();
            steamUpdateServer.StartInfo.UseShellExecute = true;
            steamUpdateServer.StartInfo.RedirectStandardInput = false;
            steamUpdateServer.StartInfo.RedirectStandardOutput = false;
            steamUpdateServer.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            steamUpdateServer.EnableRaisingEvents = true;
            steamUpdateServer.StartInfo.FileName = Server.SteamCMDDir + "\\SteamCMD.exe ";
            steamUpdateServer.StartInfo.Arguments = SteamCMDCommand(Server);

            steamUpdateServer.Start();

            steamUpdateServer.Exited += (sender, e) =>
            {
                Console.WriteLine(DateTime.Now + ": Process Complete for " + Server.GamePort + "    Time: {0} sec " +
                "Exit code:    {1}", DateTime.Now.Second - steamUpdateServer.StartTime.Second, steamUpdateServer.ExitCode);

                if (!Server.stopServerTimer)
                {
                    Server.GameUpdateNeeded = NeedsArkUpdate(Server);
                    Server.ModUpdateNeeded = NeedsModUpdate(Server);

                }
                StartServerProcedure(Server);
                ((Process)sender).Dispose();
            };
        }
        public static bool NeedsArkUpdate(ArkServerInfo Server)
        {
            string svrmajorRevision = "";
            string svrminorRevision = "";
            string tmpsvrBuildVersionNumber = "";
            string buildVersionNumber = "";
            string[] svrrevisionArray = new string[2];
            string updatedmajorRevision = "";
            string updatedminorRevision = "";
            string[] updatedrevisionArray = new string[2];
            
            tmpsvrBuildVersionNumber = File.ReadLines(Server.VersionPath).First().Replace(" ", "");
            buildVersionNumber = File.ReadLines(StableServer_Main.VersionServerInfo().VersionPath).First().Replace(" ","");

            int svrmajRevInt = 0;
            int updatedmajRevInt = 0;
            int svrminRevInt = 0;
            int updatedminRevInt = 0;

            updatedrevisionArray = buildVersionNumber.Split('.');
            updatedmajorRevision = updatedrevisionArray[0];
            updatedminorRevision = updatedrevisionArray[1];

            svrrevisionArray = tmpsvrBuildVersionNumber.Split('.');
            svrmajorRevision = svrrevisionArray[0];
            svrminorRevision = svrrevisionArray[1];

            

            while(svrminorRevision.Count() < updatedminorRevision.Count())
            {
                svrminorRevision += "0";
            }
            while (svrminorRevision.Count() > updatedminorRevision.Count())
            {
                updatedminorRevision += "0";
            }

            Int32.TryParse(updatedmajorRevision, out updatedmajRevInt);
            Int32.TryParse(updatedminorRevision, out updatedminRevInt);
            Int32.TryParse(svrmajorRevision, out svrmajRevInt);
            Int32.TryParse(svrminorRevision, out svrminRevInt);

            if (updatedminRevInt > svrminRevInt && updatedmajRevInt >= svrmajRevInt)
            {
                Console.WriteLine(DateTime.Now + ": " + Server.Name + " needs Ark Update. Min Revision");
                //Log(port, DateTime.Now + ": " + Server.Name + " needs Ark Update. Min Revision");
                return true;
            }
            if (updatedmajRevInt > svrmajRevInt)
            {
                Console.WriteLine(DateTime.Now + ": " + Server.Name + " needs Ark Update. Maj Revision");
               //Log(port, DateTime.Now + ": " + Server.Name + " needs Ark Update. Maj Revision");
                return true;
            }
            return false;
        }
        public static string SteamCMDCommand(ArkServerInfo Server)
        {
            string command = "+login anonymous +force_install_dir " + Server.ServerDir + " +app_update 376030";
            command = command + " +force_install_dir " + Server.SteamWorkshopDownloadDir;
            foreach (string mod in ActiveServerMods(Server))
            {
                command = command + " +workshop_download_item 346110 " + mod;
            }

            command = command + " +quit";
            return command;
        }
        public static bool IsProcessOpen(ArkServerInfo Server)
        {
            try
            {
                Process[] processes = Process.GetProcessesByName(GlobalVariables.appName);
                foreach (Process clsProcess in processes)
                {
                    if (clsProcess.ProcessName.Contains(GlobalVariables.appName))
                    {
                        if (clsProcess.MainModule.FileName.Contains(Server.ServerDir))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now + ": Exception occured when checking if ShooterGameServer.exe is an active process. Exception: " + ex.Message);
                //Log(port, DateTime.Now + ": Exception occured when checking if ShooterGameServer.exe is an active process. Exception: " + ex.Message);
            }
            return false;
        }

        public static string[] ActiveServerMods(ArkServerInfo Server)
        {
            string[] activeMods;

            var parser = new FileIniDataParser();
            parser.Parser.Configuration.AllowDuplicateKeys = true;
            IniData serverData = new IniData();
            serverData = parser.ReadFile(Server.GUSFile);

            activeMods = serverData["ServerSettings"]["ActiveMods"].Split(',');

            return activeMods;
        }
        public static string[] AllActiveServerMods()
        {
            List<ArkServerInfo> Servers = new List<ArkServerInfo>();
            int numOfServers;
            string[] activeMods;
            string[] ServerDirs = File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServerDirectories.txt"));
            numOfServers = ServerDirs.Length;
            foreach (var server in ServerDirs)
            {
                ArkServerInfo tempServer = new ArkServerInfo();
                string[] serverInfo = { "" };
                serverInfo = server.Split(',');
                tempServer.Name = serverInfo[0];
                tempServer.ServerDir = serverInfo[1];
                Servers.Add(tempServer);
            }
            List<string> AllMods = new List<string>();
            foreach (var server in Servers)
            {
                foreach(var mod in server.Mods)
                {
                    AllMods.Add(mod);
                }
            }
            activeMods = AllMods.Distinct().Select(i => i.ToString()).ToArray();

            return activeMods;
        }
        private static List<string[]> UpdatedModNTime = new List<string[]>();
        private static List<string[]> ServerModNTime = new List<string[]>();
        public static bool NeedsModUpdate(ArkServerInfo Server)
        {
            bool workshopItemNeedsUpdate = false;
            AcfReader serverReader = new AcfReader(Server.AppWorkshopACF);
            serverReader.ACFFileToStruct();
            serverReader.CheckIntegrity();
            ACF_Struct workshopACF = serverReader.ACFFileToStruct();

            AcfReader updateReader = new AcfReader(StableServer_Main.VersionServerInfo().AppWorkshopACF);
            updateReader.ACFFileToStruct();
            updateReader.CheckIntegrity();
            ACF_Struct UpdateWorkshopACF = updateReader.ACFFileToStruct();

            foreach (string mod in AllActiveServerMods())
            {
                string[] UpdatedModNTimeData = new string[2];
                UpdatedModNTimeData[0] = mod;
                try
                {
                    UpdatedModNTimeData[1] = UpdateWorkshopACF.SubACF["AppWorkshop"].SubACF["WorkshopItemsInstalled"].SubACF[mod].SubItems["timeupdated"];
                }
                catch (Exception ex)
                {
                    Console.WriteLine(DateTime.Now + ": Error in NeedsModUpdate in AllActiveServerMods on mod "+mod+ " with exception: " + ex.Message );
                    //Log(port, DateTime.Now + ": Exception occured when trying to read all active mod's timeupdated value. Exception: " + ex.Message);
                    break;
                }
                UpdatedModNTime.Add(UpdatedModNTimeData);
            }
            foreach (string mod in ActiveServerMods(Server))
            {
                string[] ServerModNTimeData = new string[2];
                ServerModNTimeData[0] = mod;
                try
                {
                    ServerModNTimeData[1] = workshopACF.SubACF["AppWorkshop"].SubACF["WorkshopItemsInstalled"].SubACF[mod].SubItems["timeupdated"];
                }
                catch (Exception ex)
                {
                    Console.WriteLine(DateTime.Now + ": Error reading working time updated element. Exception: " + ex.Message);
                    //Log(port, DateTime.Now + ": Error reading working time updated element. Exception: " + ex.Message);
                }

                ServerModNTime.Add(ServerModNTimeData);
            }
            foreach (string[] BMod in UpdatedModNTime)
            {
                foreach (string[] AMod in ServerModNTime)
                {
                    //if (BMod[0] != "1257464589")
                        if (BMod[0] == AMod[0])
                        {
                            if (BMod[1] != AMod[1])
                            {
                                workshopItemNeedsUpdate = true;
                                Server.theModNeedingUpdate = GlobalVariables.NameOfMod(BMod[0]);
                                Console.WriteLine(DateTime.Now.ToString() + ": Restart Triggered for Server " + Server.Name + "  to update the following mod: " + BMod[0] + "-" + GlobalVariables.NameOfMod(BMod[0]));
                                //Log(port, DateTime.Now.ToString() + ": Restart Triggered to update the following mod: " + BMod[0] + "-" + GlobalVariables.NameOfMod(BMod[0]));
                                break;
                            }
                            if (BMod[1] == AMod[1])
                            {
                                workshopItemNeedsUpdate = false;
                            }
                        }
                }
                if (workshopItemNeedsUpdate)
                {
                    break;
                }
            }
            UpdatedModNTime.Clear();
            ServerModNTime.Clear();


            return workshopItemNeedsUpdate;
        }
        
        //public static void BackupServerFiles(int port)
        //{
        //    List<string> listOfBackups = new List<string>();
        //    string SourcePath = GlobalVariables.PortToBackupSourceDir(port);
        //    string DateStamp = "Backup_" + DateTime.Now.ToString("MMddyyyy_hhmmss");
        //    string DestinationPath = GlobalVariables.PortToBackupDestinationDir(port);

        //    //Now Create all of the directories
        //    foreach (string dirPath in Directory.GetDirectories(SourcePath, "*", SearchOption.AllDirectories))
        //        Directory.CreateDirectory(dirPath.Replace(SourcePath, DestinationPath + DateStamp));

        //    string[] fileEntries = Directory.GetDirectories(DestinationPath);
        //    foreach (string fileName in fileEntries)
        //        listOfBackups.Add(fileName);
        //    Array.Clear(fileEntries, 0, fileEntries.Length);

        //    //Copy all the files & Replaces any files with the same name
        //    try
        //    {
        //        foreach (string newPath in Directory.GetFiles(SourcePath, "*.*",
        //        SearchOption.AllDirectories).Where(name => !name.Contains("SaveGames")))
        //            File.Copy(newPath, newPath.Replace(SourcePath, DestinationPath + DateStamp), true);
        //        Log(port, DateTime.Now + "Server " + port + ": Files copied to backup");

        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(DateTime.Now + ": Could not save back up since: " + ex.Message);
        //        Log(port, DateTime.Now + ": Could not save back up since: " + ex.Message);
        //    }

        //    if (listOfBackups.Count() > 25)
        //    {
        //        if (Directory.Exists(listOfBackups[0]))
        //            DeleteDirectory(listOfBackups[0]);
        //        listOfBackups.RemoveAt(0);
        //    }
        //}
        //public static void DeleteDirectory(string target_dir)
        //{
        //    string[] files = Directory.GetFiles(target_dir);
        //    string[] dirs = Directory.GetDirectories(target_dir);

        //    foreach (string file in files)
        //    {
        //        File.SetAttributes(file, FileAttributes.Normal);
        //        File.Delete(file);
        //    }

        //    foreach (string dir in dirs)
        //    {
        //        DeleteDirectory(dir);
        //    }

        //    Directory.Delete(target_dir, false);
        //}
        //public static void Log(int port, string message)
        //{
        //    string filepath = GlobalVariables.PortToBackupSourceDir(port) + "/" + StableServer.logFileName;
        //    if (!File.Exists(filepath))
        //    {
        //        using (FileStream fs = File.Create(filepath))
        //        {

        //        }

        //    }
        //    if (File.Exists(filepath))
        //    {
        //        using (System.IO.StreamWriter file =
        //            File.AppendText(filepath))
        //        {
        //            file.WriteLine(message);
        //        }
        //    }

        //}
    }
}
