﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IniParser;
using IniParser.Model;
using SteamKit2;

namespace SASv2
{
    class GlobalVariables
    {
        public static string NameOfMod(string numOfMod)
        {
            string nameofmod = numOfMod;
            switch (numOfMod)
            {
                case "558079412":
                    nameofmod = "ACM V2.7.1294";
                    break;
                case "566885854":
                    nameofmod = "Death Helper";
                    break;
                case "566887000":
                    nameofmod = "Pet Finder";
                    break;
                case "600705968":
                    nameofmod = "ORP2";
                    break;
                case "639066374":
                    nameofmod = "PvP Safe Zones";
                    break;
                case "693416678":
                    nameofmod = "Reusable Plus";
                    break;
                case "719928795":
                    nameofmod = "Platforms Plus";
                    break;
                case "731604991":
                    nameofmod = "Structures Plus (S+)";
                    break;
                case "812655342":
                    nameofmod = "Automated Ark";
                    break;
                case "842913750":
                    nameofmod = "HG Stacking Mod";
                    break;
                case "958439036":
                    nameofmod = "Engram Unlocker";
                    break;
                case "1092557691":
                    nameofmod = "SELVision";
                    break;
                case "1230823992":
                    nameofmod = "NemUI";
                    break;
            }
            return nameofmod;
        }
        public static string appName = "ShooterGameServer";
        public static string serverRestartNotification(int timeTillRestart)
        {
            string serverMessage = "";
            if (timeTillRestart > 0)
                serverMessage = string.Format("Server is going to restart in: {0} minutes.", timeTillRestart.ToString());
            if (timeTillRestart == 0)
                serverMessage = "Server is restarting. See you on the flipside!";
            return serverMessage;
        }

        //Stability App Settings
        //public static int timeIntervalMaintenanceRestart = 240;
        public static int presetTimeToRestart = 10;
    }
    public class ArkServerInfo
    {
        public string Name { get; set; }
        public string IPAddress { get { return "127.0.0.1"; } }
        public string ServerTitle
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();
                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["SessionName"];
            }
        }
        public string QueryPort
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["QueryPort"];
            }
        }
        public string GamePort {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["Port"];
            }
        }
        public string RCONPort {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["RCONPort"];
            }
        }
        public string[] Mods {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["ActiveMods"].Split(',');
            }
        }
        public string ServerPassword {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["ServerAdminPassword"];
            }
        }
        public string ServerDir { get; set; }
        public string SteamCMDDir { get { return this.ServerDir + @"\Engine\Binaries\ThirdParty\SteamCMD\Win64\"; } }
        public string iniDir { get{ return this.ServerDir + @"ShooterGame\Saved\Config\WindowsServer\"; } }
        public string GameINIFile{ get { return this.iniDir + @"Game.ini"; } }
        public string GUSFile { get { return this.iniDir + @"GameUserSettings.ini"; } }
        public string RunBatFile { get { return this.iniDir + @"RunServer.cmd";  } }
        public string SteamWorkshopDownloadDir { get { return this.SteamCMDDir + @"\steamapps\workshop\"; } }
        public string UpdateCommand { get; set; }
        public string VersionPath { get{ return this.ServerDir + "\\version.txt"; }}
        public string AppWorkshopACF { get { return this.SteamWorkshopDownloadDir + @"appworkshop_346110.acf"; } }
        public string GameAppManifestACF { get { return this.ServerDir + @"steamapps\appmanifest_376030.acf"; } }
        public string theModNeedingUpdate { get; set; }

        public bool ModUpdateNeeded { get; set; }
        public bool isProcessOpen {
            get
            {
                try
                {
                    Process[] processes = Process.GetProcessesByName(GlobalVariables.appName);
                    foreach (Process clsProcess in processes)
                    {
                        if (clsProcess.ProcessName.Contains(GlobalVariables.appName))
                        {
                            if (clsProcess.MainModule.FileName.Contains(this.ServerDir))
                            {
                                return true;
                            }
                        }
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(DateTime.Now + ": Exception occured when checking if ShooterGameServer.exe is an active process. Exception: " + ex.Message);
                    //Log(port, DateTime.Now + ": Exception occured when checking if ShooterGameServer.exe is an active process. Exception: " + ex.Message);
                }
                return false;
            }
        }
        public bool GameUpdateNeeded { get; set; }
        public bool stopServerTimer { get; set; }

        public int nEventsProcessOpenNotResponding { get; set; }
        public int nOfTicks { get; set; }
        public int nNotRunning { get; set; }
    }
    public class VersionServerInfo
    {
        public string Name {
            get
            {
                string serverDir;
                string[] server = File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UpdateServer.txt"));
                serverDir = server[0];

                return serverDir;
            }
        }
        public string IPAddress { get; set; }
        public string ServerTitle
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();
                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["SessionName"];
            }
        }
        public string QueryPort
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["QueryPort"];
            }
        }
        public string GamePort
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["SessionSettings"]["Port"];
            }
        }
        public string RCONPort
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["RCONPort"];
            }
        }
        public string[] Mods
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["ActiveMods"].Split(',');
            }
        }
        public string ServerPassword
        {
            get
            {
                var parser = new FileIniDataParser();
                parser.Parser.Configuration.AllowDuplicateKeys = true;
                IniData data = new IniData();

                data = parser.ReadFile(this.GUSFile);
                return data["ServerSettings"]["ServerAdminPassword"];
            }
        }
        public string ServerDir {
            get
            {
                string serverDir;
                string[] server = File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UpdateServer.txt"));
                serverDir = server[0].Split(',')[1];

                return serverDir;
            }
        }
        public string SteamCMDDir { get { return this.ServerDir + @"Engine\Binaries\ThirdParty\SteamCMD\Win64\"; } }
        public string iniDir { get { return this.ServerDir + @"ShooterGame\Saved\Config\WindowsServer\"; } }
        public string GameINIFile { get { return this.iniDir + @"Game.ini"; } }
        public string GUSFile { get { return this.iniDir + @"GameUserSettings.ini"; } }
        public string RunBatFile { get { return this.iniDir + @"RunServer.cmd"; } }
        public string SteamWorkshopDownloadDir { get { return this.SteamCMDDir + @"\steamapps\workshop\"; } }
        public string UpdateCommand { get; set; }
        public string VersionPath { get { return this.ServerDir + "\\version.txt"; } }
        public string AppWorkshopACF { get { return this.SteamWorkshopDownloadDir + @"appworkshop_346110.acf"; } }
        public string GameAppManifestACF { get { return this.ServerDir + @"steamapps\appmanifest_376030.acf"; } }
        public string theModNeedingUpdate { get; set; }

        public bool ModUpdateNeeded { get; set; }
        public bool GameUpdateNeeded { get; set; }
        public bool stopServerTimer { get; set; }

        public int nEventsProcessOpenNotResponding { get; set; }
    }
}
